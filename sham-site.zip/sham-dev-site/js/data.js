/* ============================================================
   WORKS — the archive loaded into the machine.

   Sham's own builds. No vid for any entry — the poster (`img`) is
   shown straight on the PSP screen with no video texture.
   ============================================================ */
window.SK_WORKS = [
  {
    id: 'autotrade',
    title: 'Autotrade',
    sub: 'DonutSMP autosell, login-gated',
    kind: 'PROJECT',
    year: '2026',
    meta: 'PROJECT · DISCORD BOT ADMIN PANEL',
    img: 'assets/works/autotrade.jpg',
    link: 'https://github.com/y2k-sham',
    vertical: false,
    featured: true
  },
  {
    id: 'donutflash',
    title: 'DonutFlash',
    sub: 'Minecraft-themed currency store',
    kind: 'PROJECT',
    year: '2026',
    meta: 'PROJECT · DONUTSMP STORE',
    img: 'assets/works/donutflash.jpg',
    link: 'https://github.com/y2k-sham',
    vertical: false
  },
  {
    id: 'donutcoin',
    title: 'DonutCoin',
    sub: 'Single-file, green theme',
    kind: 'PROJECT',
    year: '2026',
    meta: 'PROJECT · DONUTSMP-STYLE SITE',
    img: 'assets/works/donutcoin.jpg',
    link: 'https://github.com/y2k-sham',
    vertical: false
  },
  {
    id: 'bio',
    title: 'Bio Page',
    sub: 'guns.lol-style link page',
    kind: 'PROJECT',
    year: '2026',
    meta: 'PROJECT · LINK-IN-BIO SITE',
    img: 'assets/works/bio.jpg',
    link: 'https://github.com/y2k-sham',
    vertical: false
  },
  {
    id: 'portfolio',
    title: 'Portfolio',
    sub: 'sham? — big projects, in the works',
    kind: 'PROJECT',
    year: '2026',
    meta: 'PROJECT · IN PROGRESS',
    img: 'assets/works/portfolio.jpg',
    link: 'https://github.com/y2k-sham',
    vertical: false
  }
];
